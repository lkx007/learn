#!/bin/bash
#Copyright (c) Huawei Technologies Co.,All rights reserved.

#tools version and release date is used to identify tool

#script direction
FILEDIRECTORY=$(dirname "$0")
cd "${FILEDIRECTORY}"
chmod u+x -R * >/dev/null 2>&1
. modules/lib/log.sh

#get version
TOOL_VERSION=`cat version.ini | awk 'NR==1'`
TOOL_VERSION=${TOOL_VERSION#*\"}
TOOL_VERSION=${TOOL_VERSION%\"*}

#get release date
TOOL_RELEASE_DATE=`cat version.ini | awk 'NR==2'`
TOOL_RELEASE_DATE=${TOOL_RELEASE_DATE#*\"}
TOOL_RELEASE_DATE=${TOOL_RELEASE_DATE%\"*}

#get supported os list
REDHAT=`cat config.ini |grep "Redhat Support Version"|awk -F: '{print $2}'`
SLES=`cat config.ini |grep "SLES Support Version"|awk -F: '{print $2}'`
UBUNTU=`cat config.ini |grep "Ubuntu Support Version"|awk -F: '{print $2}'`

#collected log is saved to the direction
OUTPUTLOG="$(hostname)_$(date +%Y%m%d_%H%M%S)"


################################################################
#Function:		<get_DA_lspci_info>
#Description:	get DA200 pci information 
#Parameter:	NA
#Return:	DA200 logs
#Since:		bigdata\logCollect.cfg
#Other:		N/a				
###################################################################
function get_DA_lspci_info()
{
    local log_dir="${OUTPUTLOG}/bigdata"
    local ret=0
    # Get fireware lspci info
    run_cmd "lspci | grep d501" "${log_dir}/lspci_log.txt"
    if [ 0 -ne $? ]
    then
        LOG_ERROR "Get DA200 pci info failed."
        ret=1
    else
        LOG_INFO "Get DA200 pci info succeed."
    fi    
    return $ret
}

################################################################
#Function:		<get_DA_selfdiag_info>
#Description:	get DA200 self diag information 
#Parameter:	NA
#Return:	DA200 logs
#Since:		bigdata\logCollect.cfg
#Other:		N/a				
###################################################################
function get_DA_selfdiag_info()
{
    local log_dir="${OUTPUTLOG}/bigdata"
    local ret=0
    # Get fireware lspci info
    run_cmd "/opt/DA200/compress_tools/tools/dcadm selfdiag" "${log_dir}/selfdiag_log.txt"
    if [ 0 -ne $? ]
    then
        LOG_ERROR "Get DA200 self diag info failed."
        ret=1
    else
        LOG_INFO "Get DA200 self diag info succeed."
    fi    
    return $ret
}

################################################################
#Function:		<get_logic_disk_map>
#Description:	get the disk map between logic and physical log file 
#Parameter:	NA
#Return:	logs
#Since:		logCollect.cfg
#Other:		N/a				
###################################################################
 function get_logic_disk_map()
{
 	local log_dir="${OUTPUTLOG}/raid/diskmap.txt"
 	run_cmd "lsscsi" "${log_dir}"
 	if [ "$(uname -m)" == "x86_64" ]; then
 		TOOLS="opt/MegaRAID/storcli/storcli64"
 	else
 		TOOLS="opt/MegaRAID/storcli/storcli"
 	fi
	num=`"${TOOLS}" show ctrlcount | grep "Controller Count"| awk -F "=" '{print $2}'| tr -d '\r\n'`
 	for((i=0;i<$num;i++))
 	do
 		run_cmd "${TOOLS} /c$i show" "${log_dir}"
	done
	return 0
}
################################################################
#Function:		<get_sas_raid_log>
#Description:	get lsi3108/2208 log file 
#Parameter:	NA
#Return:	logs
#Since:		logCollect.cfg
#Other:		N/a				
###################################################################
 function get_sas_raid_log()
 {  
	local TOOLS=""
	local adpCnt=0
	local log_file="${OUTPUTLOG}/raid/sasraidlog.txt"


    if [ "$(uname -m)" == "x86_64" ]; then
        TOOLS="opt/MegaRAID/storcli/storcli64"
    else
        TOOLS="opt/MegaRAID/storcli/storcli"
    fi
    
     
    adpCnt=`$TOOLS -AdpAllinfo -aALL | grep -i "device id" | wc -l`

    run_cmd "$TOOLS /call/vall show all" "${log_file}"

    run_cmd "$TOOLS -AdpAllInfo -aALL" "${log_file}"

    run_cmd "$TOOLS -PDList -aALL" "${log_file}"

    run_cmd "$TOOLS -adpalilog -aALL" "${log_file}"

    run_cmd "$TOOLS -adpbbucmd -aALL" "${log_file}"

    run_cmd "$TOOLS /call/pall show all" "${log_file}"

    # collect link errorcode log
    run_cmd "$TOOLS /call/eall show phyerrorcounters" "${log_file}"
    run_cmd "$TOOLS /call/eall/sall show phyerrorcounters" "${log_file}"

	return 0

}
################################################################
#Function:		<get_lsi2308_log>
#Description:	get lsi2308 log file 
#Parameter:	NA
#Return:	2308 logs
#Since:		logCollect.cfg
#Other:		N/a				
###################################################################
function get_lsi2308_log()
{
    local sas2ircu="modules/raid/RAIDtool/2308/sas2ircu"
    local sas2flash="modules/raid/RAIDtool/2308/sas2flash"
    local log_file="${OUTPUTLOG}/raid/sashbalog.txt"
    local adpCnt=$($sas2ircu LIST | grep "^ *[0-9]" | awk '{print $4}' | grep "87h\|86h" | wc -l)
    local hbacli="modules/raid/RAIDtool/2308/hbacli"
    for((adpNum=0;adpNum<adpCnt;adpNum++))
    do
        run_cmd "${sas2ircu} ${adpNum} display" "${log_file}"
 
        run_cmd "${sas2flash} -c $adpNum -list" "$log_file"

        run_cmd "${sas2ircu} ${adpNum} status" "${log_file}"
 
        run_cmd "${sas2ircu} ${adpNum} logir upload" "${log_file}"
    done
    run_cmd "echo -e \"1\n6\n0\n0\" | ${hbacli}" "${log_file}"
    run_cmd "echo -e \"1\n10\n\npl status\niop show diag\nexit\n0\n0\n\" | ${hbacli}" "${log_file}"
    if [ -f "logir.log" ]	
    then
        run_cmd "rm -rf logir.log"
    fi
	
    return 0


}

################################################################
#Function:		<get_lsi3008_log>
#Description:	get lsi3008 log file 
#Parameter:	NA
#Return:	3008 logs
#Since:		logCollect.cfg
#Other:		N/a				
###################################################################
function get_lsi3008_log()
{
    local sas3ircu="modules/raid/RAIDtool/3008/sas3ircu"
    local sas3flash="modules/raid/RAIDtool/3008/sas3flash"
    local log_file="${OUTPUTLOG}/raid/sashbalog.txt"
    local adpCnt=`$sas3ircu LIST | grep "SAS3008" | grep -v "Adapter" | wc -l`
    local hbacli="modules/raid/RAIDtool/3008/hbacli"
    for((adpNum=0;adpNum<adpCnt;adpNum++))
    do
        
        run_cmd "${sas3ircu} $adpNum display" "$log_file"

        run_cmd "${sas3flash} -c $adpNum -list" "$log_file"

        run_cmd "${sas3ircu}  $adpNum status" "$log_file"

        run_cmd "${sas3ircu}  $adpNum logir upload" "$log_file"
    done
    run_cmd "echo -e \"1\n6\n0\n0\" | ${hbacli}" "${log_file}"
    run_cmd "echo -e \"1\n10\n\npl status\niop show diag\nexit\n0\n0\n\" | ${hbacli}" "${log_file}"
    if [ -f "logir.log" ]
    then
        run_cmd "rm -rf logir.log"
    fi
	
    return 0

}

################################################################
#Function:		<get_module_info>
#Description:	get modue info log 
#Parameter:	NA
#Return:	3008 logs
#Since:		driver\logCollect.cfg
#Other:		N/a				
###################################################################
function get_module_info()
{
    local log_dir="${OUTPUTLOG}/driver/modinfo.txt"
    local ret=0
    local cmd
    modinfo nvme >/dev/null 2>&1
    if [ 0 -eq $? ]
    then
        lsmod | awk '{
                    if(NR!=1)
                    {
                        print "modinfo " $1; 
                        print "{";
                        cmd = sprintf("modinfo %s",$1);
                        system(cmd);
                        print "}";
                    }
                }' >> "$log_dir"
                ret=$?
    else
        lsmod | grep -v "nvme" | awk '{
                    if(NR!=1)
                    {
                        print "modinfo " $1; 
                        print "{";
                        cmd = sprintf("modinfo %s",$1);
                        system(cmd);
                        print "}";
                    }
                }' >> "$log_dir"
                ret=$?
    fi
    
    if [ "${ret}" -eq 0 ]; then
        LOG_INFO "Get modinfo success"
    else
        LOG_ERROR "Get modinfo fail and exitCode is ${ret}"
    fi

    return "$ret"
}

################################################################
#Function:		<get_fc_port_state_info>
#Description:	get fc card port_state_info information 
#Parameter:	NA
#Return:	hba logs
#Since:		driver\logCollect.cfg
#Other:		N/a				
###################################################################
function get_fc_port_state_info()
{
    local log_dir="${OUTPUTLOG}/hba/"
    local ret=0

	cmd="ls /sys/class/fc_host/"
	result=$(eval "${cmd}" 2>&1)          
	retCode=$? 	
	
	if [ 0 -ne ${retCode} ]
	then
	   ret=$retCode
	   LOG_ERROR "[$cmd] failed.Ret:$retCode. Desc:$result"
	   LOG_ERROR "Get fc error_frames info failed."
	else	
		for host in ${result}
		do
			if [ -f "/sys/class/fc_host/${host}/port_state" ]
			then
				run_cmd "cat /sys/class/fc_host/${host}/port_state" "${log_dir}/port_state.txt"
			fi
			if [ 0 -ne $? ]
			then
				ret=1
				LOG_ERROR "get fc port_state info failed"
			fi
		done
	fi
    return "$ret"
}

################################################################
#Function:		<get_fc_error_frame_crc_info>
#Description:	get fc card error_frames and  invalid_crc_count information 
#Parameter:	NA
#Return:	hba logs
#Since:		driver\logCollect.cfg
#Other:		N/a				
###################################################################
function get_fc_error_frame_crc_info()
{
    local log_dir="${OUTPUTLOG}/hba/"
    local ret=0

	cmd="ls /sys/class/fc_host/"
	result=$(eval "${cmd}" 2>&1)          
	retCode=$? 	
	
	if [ 0 -ne ${retCode} ]
	then
	   ret=$retCode
	   LOG_ERROR "[$cmd] failed.Ret:$retCode. Desc:$result"
	   LOG_ERROR "Get fc error_frames info failed."
	else	
		for host in ${result}
		do
			if [ -f "/sys/class/fc_host/${host}/statistics/error_frames" ]
			then
				run_cmd "cat /sys/class/fc_host/${host}/statistics/error_frames" "${log_dir}/error_frame_crc.txt"
			fi
			if [ 0 -ne $? ]
			then
				ret=1
				LOG_ERROR "no fc port found or get error_frame info failed"
			fi

			if [ -f "/sys/class/fc_host/${host}/statistics/invalid_crc_count" ]
			then
				run_cmd "cat /sys/class/fc_host/${host}/statistics/invalid_crc_count" "${log_dir}/error_frame_crc.txt"
			fi
			if [ 0 -ne $? ]
			then
				ret=1
				LOG_ERROR "no fc port found or get invalid_crc_cout info failed"
			fi
		done
	fi
	return "$ret"
				
}

################################################################
#Function:		<get_fc_wwpn_info>
#Description:	get fc card wwpn information 
#Parameter:	NA
#Return:	hba logs
#Since:		driver\logCollect.cfg
#Other:		N/a				
###################################################################
function get_fc_wwpn_info()
{
    local log_dir="${OUTPUTLOG}/hba/"
    local ret=0

	cmd="ls /sys/class/fc_host/"
	result=$(eval "${cmd}" 2>&1)          
	retCode=$? 	
	
	if [ 0 -ne ${retCode}  ]
	then
	   ret=$retCode
	   LOG_ERROR "[$cmd] failed.Ret:$retCode. Desc:$result"
	   LOG_ERROR "Get fc wwpn info failed."
	else	
		for host in ${result}
		do
			run_cmd "cat /sys/class/fc_host/${host}/port_name" "${log_dir}/wwpn.txt"
			if [ 0 -ne $? ]
			then
				ret=1
				LOG_ERROR "No fc port found or get wwpn info failed."
			fi
			run_cmd "cat /sys/class/fc_host/${host}/node_name" "${log_dir}/wwpn.txt"
			if [ 0 -ne $? ]
			then
				ret=1
				LOG_ERROR "No fc port found or get wwn info failed."
			fi
		done	
	fi

    return "$ret"
}

################################################################
#Function:		<get_fc_fw_info>
#Description:	get fc card firmware information 
#Parameter:	NA
#Return:	hba logs
#Since:		driver\logCollect.cfg
#Other:		N/a				
###################################################################
function get_fc_fw_info()
{
    local log_dir="${OUTPUTLOG}/hba/"
    local ret=0
	
	cmd="ls /sys/class/scsi_host/"
	result=$(eval "${cmd}" 2>&1)          
	retCode=$? 	
	
	if [ 0 -ne "${retCode}"  ]
	then
	   ret=$retCode
	   LOG_ERROR "[$cmd] failed.Ret:$retCode. Desc:$result"
	   LOG_ERROR "Get fc fw info failed."
	else	
		for host in ${result}
		do
			if [ -f "/sys/class/scsi_host/${host}/fwrev" ]; then
           			run_cmd "cat /sys/class/scsi_host/${host}/fwrev" "${log_dir}/firmware_fc.txt"
			elif [ -f "/sys/class/scsi_host/${host}/fw_version" ]; then
				run_cmd "cat /sys/class/scsi_host/${host}/fw_version" "${log_dir}/firmware_fc.txt"
			fi	
			if [ 0 -ne $? ]
			then
				ret=1
				LOG_ERROR "No fc port found or get fw info failed."
			fi
		done	
	fi

    return "$ret"
}
################################################################
#Function:		<get_fc_driver_info>
#Description:	get fc card driver information 
#Parameter:	NA
#Return:	hba logs
#Since:		driver\logCollect.cfg
#Other:		N/a				
###################################################################
function get_fc_driver_info()
{
    local log_dir="${OUTPUTLOG}/hba/"
    local ret=0
	
	cmd="ls /sys/class/scsi_host/"
	result=$(eval "${cmd}" 2>&1)          
	retCode=$? 	
	
	if [ 0 -ne "${retCode}"  ]
	then
	   ret=$retCode
	   LOG_ERROR "[$cmd] failed.Ret:$retCode. Desc:$result"
	   LOG_ERROR "Get fc driver info failed."
	else
		for host in ${result}
		do
			if [ -f "/sys/class/scsi_host/${host}/lpfc_drvr_version" ]; then
				run_cmd "cat /sys/class/scsi_host/${host}/lpfc_drvr_version" "${log_dir}/driver_fc.txt"
			elif [ -f "/sys/class/scsi_host/${host}/driver_version" ]; then
				run_cmd "cat /sys/class/scsi_host/${host}/driver_version" "${log_dir}/driver_fc.txt"
			fi
			if [ 0 -ne $? ]
			then
				ret=1
				LOG_ERROR "No fc port found or get fc driver info failed."
			fi
		done	
	fi

    return "$ret"
}

################################################################
#Function:      <get_reboot_info>
#Description:   get reboot information
#Parameter:     NA
#Return:        reboot info from last logs
#Since:         system\logCollect.cfg
#Other:         N/a
###################################################################
function get_reboot_info()
{
    local log_dir="${OUTPUTLOG}/system/"
    local ret=0
    run_cmd "/usr/bin/last -xF | grep 'reboot\|shutdown\|runlevel\|system'" "${log_dir}/command_log.txt"
    if [ 0 -ne $? ]
    then
        ret=1
        LOG_ERROR "Get reboot info from last failed."
    fi

    return "$ret"
}

################################################################
#Function:		<get_eth_pci_info>
#Description:	get nic pci information 
#Parameter:	NA
#Return:	hba logs
#Since:		driver\logCollect.cfg
#Other:		N/a				
###################################################################
function get_eth_pci_info()
{
    local log_dir="${OUTPUTLOG}/nic"
    local ret=0
    # Get nic lspci info
    run_cmd "lspci | grep Ethernet" "${log_dir}/lspci_eth.txt"
    if [ 0 -ne $? ]
    then
        LOG_ERROR "Get ethernet pci info failed."
        ret=1
    else
        LOG_INFO "Get ethernet pci info succeed."
    fi
    return $ret
}

################################################################
#Function:		<get_fc_pci_info>
#Description:	get fc pci information 
#Parameter:	NA
#Return:	hba logs
#Since:		driver\logCollect.cfg
#Other:		N/a				
###################################################################
function get_fc_pci_info()
{
    local log_dir="${OUTPUTLOG}/hba"
    local ret=0
    # Get fireware lspci info
    run_cmd "lspci | grep Fibre" "${log_dir}/lspci_fc.txt"
    if [ 0 -ne $? ]
    then
        LOG_ERROR "Get fibre pci info failed."
        ret=1
    else
        LOG_INFO "Get fibre pci info succeed."
    fi    
    return $ret
}


################################################################
#Function:		<get_nic_error_frame_crc_info>
#Description:	get nic card error_frames and  invalid_crc_count information 
#Parameter:	NA
#Return:	nic logs
#Since:		nic\logCollect.cfg
#Other:		N/a				
###################################################################
function get_nic_error_frame_crc_info()
{
    local log_dir="${OUTPUTLOG}/nic/"
    local ret=0

	cmd="ls /sys/class/net/"
	result=$(eval "${cmd}" 2>&1)          
	retCode=$? 	
	
	if [ 0 -ne ${retCode} ]
	then
	   ret=$retCode
	   LOG_ERROR "[$cmd] failed.Ret:$retCode. Desc:$result"
	   LOG_ERROR "Get nic error_frames info failed."
	else	
		for netname in ${result}
		do
			if [ -f "/sys/class/net/${netname}/statistics/rx_crc_errors" ]
			then
			    run_cmd "cat /sys/class/net/${netname}/statistics/rx_crc_errors" "${log_dir}/error_frame_crc.txt"
			fi
			if [ 0 -ne $? ]
			then
			    ret=1
			    LOG_ERROR "Get nic crc info failed."
			fi
			if [ -f "/sys/class/net/${netname}/statistics/rx_frame_errors" ]
			then
			    run_cmd "cat /sys/class/net/${netname}/statistics/rx_frame_errors" "${log_dir}/error_frame_crc.txt"
			fi
			if [ 0 -ne $? ]
			then
			    ret=1
			    LOG_ERROR "Get nic error_frame info failed."
			fi
		done
	fi
	return ${ret}
}

################################################################
#Function:		<get_ethtool_info>
#Description:	get nic info by ethtool 
#Parameter:	NA
#Return:	3008 logs
#Since:		nic\logCollect.cfg 
#Other:		N/a				
###################################################################
function get_ethtool_info()
{
    #Nic config info
    local log_dir="${OUTPUTLOG}/nic/ethtool.txt"
    local nic_devices=""
    local device=""

    nic_devices=$(ls /sys/class/net/  2>&1)
    for device in ${nic_devices}
    do
        if [ "${device}" != 'lo' ]
        then             
            run_cmd  "ethtool -i ${device}" "${log_dir}"     
            run_cmd  "ethtool ${device}" "${log_dir}"
            run_cmd  "ethtool -S ${device}" "${log_dir}"
            run_cmd  "ethtool -g ${device}" "${log_dir}"
            run_cmd  "ethtool -k ${device}" "${log_dir}"
            run_cmd  "ethtool -m ${device}" "${log_dir}"
        fi
    done
}

################################################################
#Function:		<get_sosreport_log>
#Description:	get sosreport log by sosreport command
#Parameter:	NA
#Return:	system logs
#Since:		system\logCollect.cfg 
#Other:		N/a				
###################################################################
function get_sosreport_log()
{
    local ret=0 
    local log_dir="${OUTPUTLOG}/system"
    cmd="sosreport --batch"

    run_cmd "$cmd"    
    if [ "$?" -eq 0 ]
    then
        run_cmd "mkdir -p  $log_dir/sosreport "
        if [ 0 -eq $? ]
        then
            sosreportDir="$log_dir/sosreport"
        else
            sosreportDir="${log_dir}"
        fi

        sosreport_log_tbz=$(find /tmp/ -name "sosreport-*.tar.xz" | sort -r | head -1)
        sosreport_log_tbz_md5=$(find /tmp/ -name "sosreport-*.tar.xz.md5" | sort -r | head -1)
        sosreport7_log_tbz=$(find /var/tmp/ -name "sosreport-*.tar.xz" | sort -r | head -1)
        sosreport7_log_tbz_md5=$(find /var/tmp/ -name "sosreport-*.tar.xz.md5" | sort -r | head -1)

        run_cmd "mv ${sosreport_log_tbz} ${sosreportDir}"
        run_cmd "mv ${sosreport_log_tbz_md5} ${sosreportDir}"
         
        run_cmd "mv ${sosreport7_log_tbz} ${sosreportDir}"
        run_cmd "mv ${sosreport7_log_tbz_md5} ${sosreportDir}"

        run_cmd "mv dmraid.ddf1 ${sosreportDir}" 
        ret=0
        return ${ret}
    else
        ret=1
        LOG_INFO "sosreport not support or sosreport cmd failed."
    fi

    return ${ret}

}

################################################################
#Function:		<get_suse_log>
#Description:	get suse log by supportconfig command
#Parameter:	NA
#Return:	system logs
#Since:		system\logCollect.cfg 
#Other:		N/a				
###################################################################
function get_suse_log()
{
    local ret=0 
    local log_dir="${OUTPUTLOG}/system"
    run_cmd "supportconfig -Q"
    if [ "$?" -eq 0 ]
    then
        run_cmd "mkdir -p  $log_dir/suse"
        if [ 0 -eq $? ]
        then
            suseDir="$log_dir/suse"
        else
            suseDir="${log_dir}"
        fi

        suse_tbz=$(find /var/log/ -name "nts_$(hostname)*.tbz" | sort -r | head -1)
        suse_tbz_md5=$(find /var/log/ -name "nts_$(hostname)*.tbz.md5" | sort -r | head -1)
        
        run_cmd "mv ${suse_tbz} ${suseDir}"     
        run_cmd "mv ${suse_tbz_md5} ${suseDir}"  
        ret=0
        return ${ret}
    else
        ret=1
        LOG_INFO "supportconfig not support or supportconfig failed."
    fi 

    return ${ret}
   

}

################################################################
#Function:		<get_filelist>
#Description:	get collected log file 
#Parameter:	NA 
#Return:	filelist.txt
#Since:		
#Other:		NA				
###################################################################
function get_filelist()
{
 
    run_cmd "cp runlog ${OUTPUTLOG}/system/" 
    
    cd ${OUTPUTLOG}
    local logDir=$(ls)

    #get all collect log info to filelist.txt
    for log in ${logDir}
    do
        if [ -d "${log}" ]; then            
            find ${log} ! -type d  | awk -v modu="${log}" 'BEGIN{print "\n" modu " Dir file list:";
                                                         i = 0;}
                                                        {
                                                        printf "  %-5s %s\n",i+1,$0
                                                        i = i+1               
							}' >> filelist.txt
        else
            files[${i}]="${log}"
            i=$((i+1))
        fi
    done
    
    #write file to the end of the filelist
    for((i=0;i<${#files[@]};i++))
    do
        if [ "" != "${files[${i}]}" ]
        then        
            run_cmd "ls ${files[${i}]}" "filelist.txt"
        fi
    done
    
    echo "filelist.txt" >>filelist.txt
	
    
    cd ../
	
}

function module_log_collect()
{ 
    local file=""
    local cmd=""
    local cmdType=""
    local lineNum=""
    local result="SUCCEED"
	local line=""

    moduleName="$1"
	
	LOG_INFO "${moduleName} collect start." 

	printf " Collect %.60s" "[${moduleName}] information..." 

	lineNum=`cat modules/$moduleName/logCollect.cfg 2>/dev/null | grep -v "#" | grep "|" | wc -l`

	if [ "" == "$lineNum" ] || [ "0" == "$lineNum" ]
	then
		LOG_INFO "$moduleName logCollect.cfg not found:$lineNum" 
		return
	fi


	for((line=1;line<=lineNum;line++))
	do

		lineContext=`cat modules/$moduleName/logCollect.cfg | grep -v "#" |grep "|" |  awk '(NR=='$line')'`
		file=`echo "$lineContext" | awk -F"|" '{print $3}' |  sed 's/ //g' | sed 's/[ \t]*$//g' `
		cmd=`echo "$lineContext" | awk -F"|" '{print $2}' | sed 's/^\s*\|\s*$//g'`
		cmdType=`echo "$lineContext" | awk -F"|" '{print $1}' |  sed 's/ //g' | sed 's/[ \t]*$//g'`

		cnt=`cat config.ini | grep "$file" | grep -i "yes" | grep "$moduleName" | wc -l`
		if [ "0" == $cnt ] || [ "" == "$cnt" ]
		then
			LOG_INFO "[$file] [$moduleName] not match with the config.Ret:$cnt"  
			LOG_INFO "[$file] collect SKIPPED."  
			continue
		fi

		##start collect
		LOG_INFO  "[${file}] collect start." 
		printf "\r%.75s" "                                                   "
		printf "\r Collect %.75s" "[${file}] ...... please wait"

		#make log dir
		local logDir="${OUTPUTLOG}/$moduleName"
		if [ ! -d "${OUTPUTLOG}/$moduleName" ]
		then
			run_cmd "mkdir -m a=r ${OUTPUTLOG}/$moduleName"
			LOG_INFO "Create ${OUTPUTLOG}/$moduleName ok." 
		fi

		LOG_INFO "[$file] cmd type is $cmdType." 
		
		if [ "cmd" == "$cmdType" ] || [ "CMD" == "$cmdType" ] || [ "COMMAND" == "$cmdType" ]
		then
			run_cmd "$cmd" "$logDir/$file"
			if [ "0" == "$?" ] 
			then
				LOG_INFO "$file collect ok."
				result="SUCCEED"                   
			else 
				LOG_INFO "$file collect cmd failed."
				result="FAILED"
			fi

		elif [ "file" == "$cmdType" ] || [ "FILE" == "$cmdType" ]
		then

			fileFullDir="$cmd"
			#file is exist
			infilepath=`dirname "${fileFullDir}"`
			subDir=${logDir}${infilepath}

			run_cmd "mkdir -p $subDir"
			if [ 0 -eq $? ]
			then
				logDir="$subDir"
			else 
				LOG_ERROR "mkdir -p $subDir failed." 
			fi

			run_cmd "cp -rf -L $cmd $logDir/"
			if [ "0" == "$?" ] 
			then
				LOG_INFO "$file collect ok."
				result="SUCCEED"                   
			else 
				LOG_INFO "$file collect cmd failed."
				result="FAILED"
			fi

		elif [ "FUNC" == "$cmdType" ] || [ "func" == "$cmdType" ] 
		then 
			$cmd
			if [ "0" == "$?" ] 
			then
				LOG_INFO "$file collect ok."
				result="SUCCEED"
			else 
				LOG_INFO "$file collect cmd failed."
				fi			
		else
			 LOG_ERROR "$moduleName $file cmd type [$cmdType] is invalid." 
			 result="FAILED"
		fi 

		printf "\r Collect %.60s" "[${file}] ...... Done        "

	done

	printf "\r %.60s" "[${moduleName}]...                                                                            "
	printf "%s\n" "Done"       

	LOG_INFO "${moduleName} collect finished." 

}

################################################################
#Function:		<main_collect_log>
#Description:	collect log according to config.ini and logCollect.cfg
#Parameter:	N/a	
#Return:	N/a
#Since:		
#Other:		N/a				
###################################################################
function main_collect_log()
{
    local module=$(ls modules 2>&1)
    local result="SUCCEED"
    local timeout=""
    local pid=""

    if [ -f "modules/lib/timeout.ini" ] 
    then
        timeout=`cat modules/lib/timeout.ini`
        if [[ "${timeout}" == *[!0-9]* ]] 
        then
            LOG_ERROR "Invalid timeout set value:${timeout}.User default."
            timeout=1200
        fi

        LOG_INFO "Module collect timeout value is:$timeout."

    else 
        timeout=1200
        LOG_INFO "No timeout.ini found.Module collect timeout value is default:$timeout."
    fi
    
    #install tools
    run_cmd "rm -rf opt" 
    run_cmd "cp modules/raid/RAIDtool/3108/storcli-1.15.04-1.tar.gz ."
    run_cmd "tar -xf storcli-1.15.04-1.tar.gz"

    showTitle

    for moduleName in ${module}
    do
        pid=""
        cnt=0

        module_log_collect "${moduleName}" &
        pid=$!
        LOG_INFO "Module ${moduleName} collect pid is:$pid"
        sleep 1
        for((i=0;i<timeout;i++))
        do
            ((cnt=cnt+1))
            sleep 1
            ps $pid >/dev/null
            #process finished
            if [ 0 -ne "$?" ]
            then
                LOG_INFO "Module ${moduleName} log collect process is finished in time."
                cnt=0
                break
            fi

        done 
		 
		if [ $timeout -eq $cnt ]
		then

			LOG_ERROR "Module ${moduleName} log collect process is timeout."
            LOG_INFO "kill ${moduleName} log collect process:$pid start."

            run_cmd "which pstree xargs"
            if [ 0 -eq $? ]
            then
			    #pstree $pid -p | awk -F"[()]" '{for(j=0;j<=NF;j++)if($j~/[0-9]+/)print $j}' | xargs kill -9 
                process_list=$(pstree $pid -p | awk -F'[()]' '{for(j=0;j<=NF;j++)if($j~/[0-9]+/)print $j}' | xargs)
               
                LOG_INFO "Process to kill is :$process_list"
               
                for element in $process_list
                do
                    if [[ $element == *[!0-9]* ]]
                    then   
                         LOG_INFO "Process info:$element skipped." 
                         continue
                    fi  
                    LOG_INFO "kill ${moduleName} log collect process:$element start."
                    run_cmd "kill -9 $element" 
                    LOG_INFO "kill ${moduleName} log collect process:$element end."
                done 

            else
                LOG_INFO "kill ${moduleName} log collect process:$pid start."
                run_cmd "kill -9 $pid"                
                LOG_INFO "kill ${moduleName} log collect process:$pid end."
            fi

			LOG_INFO "kill ${moduleName} log collect sub process done."
			LOG_INFO "${moduleName} log collect exsit."
            
            printf "\r %.60s" "[${moduleName}]...                                                                            "
            printf "%s\n" "Done"   
			continue
		fi		 

    done
    
    run_cmd "rm -rf storcli-1.15.04-1.tar.gz"	
    run_cmd "rm -rf CmdTool.log"
    run_cmd "rm -rf MegaSAS.log"
    run_cmd "rm -rf opt"
	
	
}

function showTitle()
{

printf "%-65.65s\n" "==============================================================================="
printf "%-65.65s\n" "        FusionServer Tools -- InfoCollect ${TOOL_VERSION}                      "
printf "%-65.65s\n" "             Release Date:${TOOL_RELEASE_DATE}                                 "
printf "%-65.65s\n" "                                                                               "
ret=`cat /proc/cmdline |grep -E "autoDiag|ftk" |wc -l`
if [ $ret -eq "0" ]
	then
	if [ ! -d "/home/Project/FTK" ];then
		printf "%-65.65s\n" " -Supported mainstream Linux 64-bit operating systems (OSs):   "
		printf "%-65.65s\n" "  ${REDHAT}                                                    "
		printf "%-65.65s\n" "  ${SLES}                                                      "
		printf "%-65.65s\n" "  ${UBUNTU}                                                    "
	fi
fi
printf "%-65.65s\n" " -Only professionals are qualified to use this tool.                           "
printf "%-65.65s\n" " -Before performing any maintenance operations by using this                   "
printf "%-65.65s\n" "  tool,obtain authorization from the customer.                                 "
printf "%-65.65s\n" " -Before transmitting fault locating data out of the customer's                "
printf "%-65.65s\n" "  network,obtain written authorized from the customer.                         "
printf "%-65.65s\n" " -Use the latest version:                                                      "
printf "%-65.65s\n" "  http://e.huawei.com, and choose Support>Downloads>IT>                        "
printf "%-65.65s\n" "  Server>TaiShan>FusionServer Tools.                                           "
printf "%-65.65s\n" "==============================================================================="

}

################################################################
#Function:		<Compression_log>
#Description:	Compression log directory
#Parameter:	N/a	
#Return:	N/a
#Since:		
#Other:		N/a				
###################################################################
function compression_log()
{   
    local file_num=""
	local compress_file="${OUTPUTLOG}.tar.gz"
	local Log_size=""
	printf "\r%-65.65s\n" "==[ DONE ]============================================================================================="

	
	run_cmd "chmod 400 -R ${OUTPUTLOG}"
	
	if [ -f ./modules/templates/generate_html.py ]
	then
		python ./modules/templates/generate_html.py "./${OUTPUTLOG}" >/dev/null 2>&1 
		if [ $? -ne 0 ]
		then
			LOG_ERROR "generate detail.html failed."
		fi
	fi
	run_cmd "tar -czf ${compress_file} ${OUTPUTLOG}"
	if [ 0 -eq $? ]
	then
        run_cmd "rm -rf ${OUTPUTLOG}"

	    run_cmd "chmod 400 ${compress_file}"

		md5sum "${compress_file}" > "${OUTPUTLOG}.md5"
		if [ $? -ne 0 ]; then
			echo -e "\033[31mcompressed file fail, please manual compression" | tee -a "${OUTPUTLOG}/system/${OUTPUTRUNLOG}\033[0m"
		else
		    run_cmd "chmod 400 ${OUTPUTLOG}.md5"

			Log_size=$(du -sh "${compress_file}"  | awk '{print $1}')
			echo -e "\033[32mLog file Dir: $(pwd)/${compress_file} \033[0m"
			echo -e "\033[32mLog file size: ${Log_size} \033[0m"
			echo -e "\033[32mLog file md5sum: $(cat ${OUTPUTLOG}.md5 | cut -d ' ' -f 1) \033[0m"
		fi
		
		file_num=$(du -a /var/crash/ 2>>/dev/null | awk 'END{ print NR}')
		if [ "${file_num}" -gt 1 ]; then
			echo -e "\033[31mPlease collect crash files[/var/crash] manually.\033[0m"
		fi
    else
	    echo -e "\033[31mCompress $OUTPUTLOG failed. Please compress manually.\033[0m"
	    LOG_ERROR "Compress $OUTPUTLOG failed. Please compress manually."
	fi
	
    printf "%-65.65s\n" "================================================================================================="
}

################################################################
#Function:		<check_auth>
#Description:	check auth id is 0
#Parameter:	N/a	
#Return:	exit 1 if not  id0 user
#Since:		
#Other:		N/a				
###################################################################
function check_auth()
{
    local login_id=$(id -u $(whoami))
    if [ "${login_id}" -ne 0 ]; then
        echo  "Current user id is ${login_id}.Recommendation to use ID:0 user to collect logs."
        LOG_ERROR "Current user id is ${login_id}.Recommendation to use ID:0 user to collect logs."
    else 
        LOG_INFO "User ID is:$(id $(whoami))"
    fi 
}

################################################################
#Function:		<run_cmd>
#Description:	exec cmd 
#Parameter:	$1��cmd to be run  $2: Variable parameter��out put the result to file�� 
#Return:	errocode  0:ok
#Since:		
#Other:		N/a				
###################################################################
function run_cmd()
{
   local ret=1
   local cmd="$1"
   local output="$2"
   local result=""
   local retCode=""

    if [ "" == "$cmd" ] || [ 2 -lt $# ] 
    then
        LOG_ERROR "Invalid parameters."
        ret=1
        return $ret 
    fi
    
    LOG_INFO "[$cmd] is called."
    result=$(eval "${cmd}" 2>&1)          
    retCode=$?
    if [ 0 -ne $retCode  ]
    then
       ret=$retCode
       LOG_ERROR "[$cmd] failed.Ret:$retCode. Desc:$result"
    else 
       ret=0
       LOG_INFO "[$cmd] successfull."
    fi 

    if [ "" != "$output" ]      
    then
       echo "${cmd}" >> "$output"  
       echo "{" >> "$output"            
       echo "$result" >> "$output" 
       echo "}" >> "$output"
    fi

    return $ret

}

################################################################
#Function:		<get_disk_partition_info>
#Description:	get disk partition info
#Parameter:	0��ok  1: error
#Return:	errocode  0:ok
#Since:		disk\logCollect.cfg 
#Other:		N/a				
###################################################################
function get_disk_partition_info()
{
    local log_dir="${OUTPUTLOG}/disk/parted_disk.txt"
    local ret=0

    ls /dev/sd* > /dev/null 2>&1
    if [ 0 -eq $? ]
    then
       sd_list=($(ls /dev/sd* | grep -v [1-9]))
    else
       LOG_ERROR "No logical disk found."
       return 
    fi

    local thread=5
    local sd_timeout=300
    local sd_num=${#sd_list[@]}

    for((i=0;i<$sd_num;i+=$thread))
    do
        local concur_thread_num=$thread
        thread_num=$(expr $i + $thread)
        if [ $thread_num -gt $sd_num ]
        then
            thread_num=$(expr $sd_num - $i)
            concur_thread_num=$thread_num
        fi

        start_sd_id=$i
        end_sd_id=$(expr $i + $concur_thread_num)
        
        for((j=$start_sd_id;j<$end_sd_id;++j))
        do
        {
            current_cmd=${sd_list[$j]}
            log_file_id="${OUTPUTLOG}/disk/parted_${j}.txt"
            run_cmd "parted ${current_cmd} print" "$log_file_id" &
            pid=$!
            local cnt=0
            sleep 1
            for((k=0;k<$sd_timeout;k++))
            do
                ((cnt=cnt+1))
                sleep 1
                ps $pid >/dev/null
                #process finished
                if [ 0 -ne $? ]
                then
                    LOG_INFO "Parted ${current_cmd} log collect process is finished in time."
                    break
                fi
            done
 
            if [ $sd_timeout -eq $cnt ]
            then
                ret=1
                LOG_ERROR "Parted ${current_cmd} log collect process is timeout."
                LOG_INFO "kill parted ${current_cmd} log collect process:$pid start."

                run_cmd "which pstree xargs"
                if [ 0 -eq $? ]
                then
                    process_list=$(pstree $pid -p | awk -F'[()]' '{for(m=0;m<=NF;++m)if($m~/[0-9]+/)print $m}' | xargs)

                    LOG_INFO "Process to kill is :$process_list"

                    for element in process_list
                    do
                        if [[ $element == *[!0-9]* ]]
                        then
                            LOG_INFO "Process info: $element skipped."
                            continue
                        fi
                        LOG_INFO "kill parted ${current_cmd} log collect process: $element start."
                        run_cmd "kill -9 $element"
                        LOG_INFO "kill parted ${current_cmd} log collect process: $element end."
                    done
                else
                    LOG_INFO "kill parted ${current_cmd} log collect process: $pid start."
                    run_cmd "kill -9 $pid"
                    LOG_INFO "kill parted ${current_cmd} log collect process: $pid end."
                fi
                LOG_INFO "kill parted ${current_cmd} log collect sub process done."
                LOG_INFO "parted ${current_cmd} log collect information exist."
            fi
        }&
        done
        wait
    done

    for((i=0;i<$sd_num;i++))
    do
        local log_file_id="${OUTPUTLOG}/disk/parted_${i}.txt"
        if [ -f ${log_file_id} ]
        then
            cat $log_file_id >> $log_dir
            rm -f $log_file_id
        fi
    done
    
    return $ret
}

################################################################
#Function:		<get_disk_smart_info>
#Description:	get disk smart info
#Parameter:	0��ok  1: error
#Return:	errocode  0:ok
#Since:		disk\logCollect.cfg 
#Other:		N/a				
###################################################################
function get_disk_smart_info()
{
    local log_dir="${OUTPUTLOG}/disk/disk_smart.txt"
    local bma_tool="/opt/huawei/bma/bin/hwdiag"
    local ret=0
    local did=""
    local inf=""
    local dnum=0
   
    if [ "$(uname -m)" == "x86_64" ]; then
        TOOLS="opt/MegaRAID/storcli/storcli64"
    else
        TOOLS="opt/MegaRAID/storcli/storcli"
    fi
    
    #get bma disk list
    run_cmd "${bma_tool} -t disk -s" "$log_dir"
   
    #judge if smartctl is in OS. if not��
    #put information "Command smartctl does not exist !" to log ${log_dir}��then exit.
    which smartctl > /dev/null 2>&1
    if [ 0 -ne $? ]
    then
        echo "Command smartctl does not exist !" >> ${log_dir}
        return
    fi
   
    local disk_cmd="${OUTPUTLOG}/disk/disk_cmd.txt"
   
    #get system LD info
    ls /dev/sd* > /dev/null 2>&1
    if [ 0 -eq $? ]
    then
        result=`ls /dev/sd* | grep -v [1-9]`
        for sd in ${result}
        do
            #run_cmd "smartctl -a ${sd}" "$log_dir"
            echo "smartctl -a ${sd}" >> $disk_cmd
            if [ 0 -ne $?  ] 
            then
               LOG_ERROR "Get $sd smart info failed."
               ret=1
            else 
               LOG_INFO "Get $sd smart info succeed."
            fi
 
            #disk num
            dnum=`"${TOOLS}" -ldpdinfo -aall | grep "Device Id:" | wc -l`
            for((i=1;i<=$dnum;i++))
            do
                #get did
                did=`"${TOOLS}" -ldpdinfo -aall | grep "Device Id:" | awk '(NR=='$i')' | awk -F": " '{print $2}' | tr -d '\r\n'`
                #get interface:sas,sata
                inf=`"${TOOLS}" -ldpdinfo -aall | grep "PD Type:" | awk '(NR=='$i')' | awk -F": " '{print $2}' | tr -d '\r\n'`
               
                #put log collect cmd to file $disk_cmd
                if [ "SAS" == "$inf" ]
                then
                    smartctl -a --device=megaraid,$did ${sd} >/dev/null
                    if [ 2 -ne "$?" ]
                    then
                        echo "smartctl -a --device=megaraid,$did ${sd}" >> $disk_cmd
                    fi
                else
                    smartctl -a --device=sat+megaraid,$did ${sd} >/dev/null
                    if [ 2 -ne "$?" ]
                    then
                        echo "smartctl -a --device=sat+megaraid,$did ${sd}" >> $disk_cmd
                    fi
                fi  
           done
        done     
    fi
    
    ls /dev/sg* > /dev/null 2>&1
    if [ 0 -eq $? ]
    then
        result=`ls /dev/sg*`
        for sg in ${result}
        do
           echo "smartctl -a ${sg}" >> $disk_cmd
        done     
    fi
    
    #collect disk log information concurrency
    if [ -f ${disk_cmd} ]
    then
        get_smart_info_concurrency "$log_dir" "$disk_cmd"
        ret=$?
        rm $disk_cmd
    fi
   
   return $ret 
}


################################################################
#Function:		<get_smart_info_concurrency>
#Description:	get disk smart info
#Parameter:	0��ok  1: error
#Return:	errocode  0:ok
#Since:		disk\logCollect.cfg 
#Other:		N/a				
###################################################################
function get_smart_info_concurrency()
{
    local log_dir=$1
    local disk_cmd=$2
    local ret=0
    
	if [ "" == "$log_dir" ] || [ "" == "$disk_cmd" ] || [ 2 -lt $# ] 
    then
        LOG_ERROR "Invalid parameters when use smartctl to collect disk information concurrency."
        ret=1
        return $ret
    fi
    
    #collect disk log information concurrency
    local disk_num=`cat ${disk_cmd} | wc -l`
	if [ 0 -eq $? ]
	then
	    local thread=5
		local disk_timeout=300
	    local run_disk_num=0
		
	    for ((i=0;i<$disk_num;i+=$thread))
		do
		    local concur_thread_num=$thread
		    thread_num=`expr $i + $thread`
			if [ $thread_num -gt $disk_num ]
			then
			    thread_num=`expr $disk_num - $i`
				concur_thread_num=$thread_num
			fi
			
			start_disk_id=`expr $i + 1`
			end_disk_id=`expr $i + $concur_thread_num`
			
			for((j=$start_disk_id;j<=$end_disk_id;++j))
			do
			{
			    current_cmd=`cat $disk_cmd | awk NR==$j`
				
				log_file_id="${OUTPUTLOG}/disk/disk_${j}.txt"
				
			    run_cmd "$current_cmd" "$log_file_id" &
				pid=$!
				local cnt=0
				sleep 1
				for((k=0;k<$disk_timeout;++k))
				do
				    ((cnt=cnt+1))
					sleep 1
					ps $pid >/dev/null
					#process finished
					if [ 0 -ne $? ]
					then
					    LOG_INFO "Command ${current_cmd} log collect process is finished in time."
						break
					fi
				done
				
				if [ $disk_timeout -eq $cnt ]
				then
				    LOG_ERROR "Command ${current_cmd} log collect process is timeout."
                    LOG_INFO "kill command ${current_cmd} log collect process:$pid start."
					
					run_cmd "which pstree xargs"
					if [ 0 -eq $? ]
					then
					    process_list=$(pstree $pid -p | awk -F'[()]' '{for(m=0;m<=NF;++m)if($m~/[0-9]+/)print $m}' | xargs)
						
						LOG_INFO "Process to kill is :$process_list"
						
						for element in process_list
						do
						    if [[ $element == *[!0-9]* ]]
							then
							    LOG_INFO "Process info: $element skipped."
								continue
							fi
							LOG_INFO "kill command ${current_cmd} log collect process: $element start."
							run_cmd "kill -9 $element"
							LOG_INFO "kill command ${current_cmd} log collect process: $element end."
						done
					else
					    LOG_INFO "kill command ${current_cmd} log collect process: $pid start."
						run_cmd "kill -9 $pid"
						LOG_INFO "kill command ${current_cmd} log collect process: $pid end."
					fi
					
					LOG_INFO "kill command ${current_cmd} log collect sub process done."
					LOG_INFO "Command ${current_cmd} log collect exist."
				fi
			}&
			done
			wait
			
		done
		
		for((i=1;i<=$disk_num;++i))
	    do
	        local log_file_id="${OUTPUTLOG}/disk/disk_${i}.txt"
            if [ -f ${log_file_id} ]
            then
                cat $log_file_id >> $log_dir
                rm -f $log_file_id
            fi
	    done
	fi
	
    return $ret
}


################################################################
#Function:		<hwdiag_disk_diag_info>
#Description:	get disk hw diag info
#Parameter:	0��ok  1: error
#Return:	errocode  0:ok
#Since:		disk\logCollect.cfg
#Other:		N/a				
###################################################################
function hwdiag_disk_diag_info()
{
   local log_dir="${OUTPUTLOG}/disk/hwdiag_hdd.txt"
   local bma_tool="/opt/huawei/bma/bin/hwdiag"
   local ret=0

   run_cmd "${bma_tool} -t disk -d" "$log_dir"
   if [ 0 -ne $?  ]
   then
       LOG_ERROR "Get disk hwdiag info failed."
       ret=1
   fi

   return $ret
}


###################################################################
#Function:		<get_es3000_v2_info>
#Description:	get ES3000 V2 PCIe SSD log info
#Parameter:	0��ok  1: error
#Return:	errocode  0:ok
#Since:		disk\logCollect.cfg
#Other:		N/a
###################################################################
function get_es3000_v2_info()
{
    local log_dir="${OUTPUTLOG}/disk/es3000_v2.txt"
    local cmd_file="modules/disk/cmdlist.ini"
    local ret=0

    which hio_info > /dev/null 2>&1
    if [ 0 -ne $? ]
    then
        echo "SSD not be found or driver unloaded.Process aborted." >> ${log_dir}
        ret=1
        return ${ret}
    fi
   
    ls /dev/hio* > /dev/null 2>&1
    if [ 0 -eq $? ]
    then
        ssd_num=`ls /dev/hio* | grep -v [0-9]`
        cmd_line_num=`cat ${cmd_file} | wc -l`
        for ssd in ${ssd_num}
        do
            for ((i=1;i<=${cmd_line_num};i++))
            do
                cmd=`cat ${cmd_file} | awk NR==$i | grep -E '^hio_'`
                cmd=${cmd/\r\n/}
                if [ 0 -eq $? ]
                then
                    whole_cmd="${cmd} -d ${ssd}"
                    run_cmd "$whole_cmd" "${log_dir}"
                fi
            done
        done
    fi
    
    return ${ret}
}


###################################################################
#Function:		<get_es3000_v3_info>
#Description:	get ES3000 V3 NVMe PCIe SSD log info
#Parameter:	0��ok  1: error
#Return:	errocode  0:ok
#Since:		disk\logCollect.cfg
#Other:     N/a	
###################################################################
function get_es3000_v3_info()
{
    local log_dir="${OUTPUTLOG}/disk/es3000_v3"
    local log_file="${OUTPUTLOG}/disk/es3000_v3/es3000_v3.txt"
    local ret=0

    run_cmd "mkdir -p ${log_dir}"

    run_cmd "modinfo nvme" "${log_file}"
    if [ $? -eq 0 ]
    then
        echo "current system has one ES3000 V3 driver." >> ${log_file}
        LOG_INFO "current system has one ES3000 V3 driver."
    else
        echo "current system has no ES3000 V3 driver." >> ${log_file}
        LOG_ERROR "current system has no ES3000 V3 driver."
    fi

    hioadm info > /dev/null 2>&1
    if [ $? -ne 0 ]
    then
        echo "Scan NVMe SSD devices failed. Process aborted." >> ${log_file}
        ret=1
        return ${ret}
    fi

    hioadm_info=($(hioadm info | grep "^|---- nvme"))

    nvme_num=$(expr ${#hioadm_info[*]} / 3)
    for ((i=0;i<${nvme_num};i++))
    do 
        nvme_index=$(expr ${i} \* 3 + 1)
        nvme=${hioadm_info[${nvme_index}]}
        # collect SMART information of the specified device
        run_cmd "hioadm info -d ${nvme} -s" "${log_file}"
        # collect advanced SMART information of the specified device
        run_cmd "hioadm info -d ${nvme} -a" "${log_file}"
        # collect controller information of the specified device
        run_cmd "hioadm info -d ${nvme}" "${log_file}"
        # collect log of the specified device
        get_es3000_v3_log "${log_dir}" "${nvme}"
    done
 
    return ${ret}
}


###################################################################
#Function:		<get_es3000_v3_log>
#Description:	get ES3000 V3 NVMe PCIe SSD log
#Parameter:	0��ok  1: error
#Return:	errocode  0:ok
#Since:		disk\logCollect.cfg
#Other:     N/a	
###################################################################
function get_es3000_v3_log()
{
    local log_dir=$1
    local nvme=$2
    local ret=0

    result=$(hioadm log -d ${nvme} -a)
    if [ $? -ne 0 ]
    then
        LOG_ERROR "Get ES3000 V3 ${nvme} log failed. Reason: ${result}"
    fi
 
    local log_file=($(ls /opt/hio | grep ".log$"))
    file_num=${#log_file[*]}
    for ((j=0;j<${file_num};j++))
    do
        run_cmd "cp /opt/hio/${log_file[$j]} ${log_dir}"
    done
    LOG_INFO "Get ES3000 V3 ${nvme} log successfully."
}


################################################################
#Function:		<get_mezz_info>
#Description:	get mezz card log info
#Parameter:	0��ok  1: error
#Return:	errocode  0:ok
#Since:		nic\logCollect.cfg
#Other:		N/a				
###################################################################
function get_mezz_info()
{
   local log_dir="${OUTPUTLOG}/nic"
   local osca_tool="modules/nic/mezz_collect.sh"
   local ret=0

    if [ ! -d "${log_dir}" ]
    then
        run_cmd "mkdir -m a=r ${log_dir}"
        LOG_INFO "Create ${log_dir} ok."
    fi

   run_cmd "./modules/nic/mezz_collect.sh"  "/dev/null"
   if [ 0 -eq $? ]
   then
       cp modules/nic/mezz_info.tar.gz $log_dir
   else
       LOG_ERROR "Get mezz log info failed."
       ret=1
   fi

   return $ret
}


#main 
function start_log_collect()
{
    LOG_INFO "InfoCollect start time is:$(date +%Y%m%d_%H%M%S)..." 

    check_auth
  
    #create log directory
    run_cmd "mkdir -m a=r -p ${OUTPUTLOG}"

    run_cmd "echo Tools verion:$TOOL_VERSION" "${OUTPUTLOG}/version.txt"  
    run_cmd "echo Tools Release date:$TOOL_RELEASE_DATE"  "${OUTPUTLOG}/version.txt"
 
    #log collect 
    main_collect_log

    #create filelist
    get_filelist

    #zip log package
    compression_log
}

start_log_collect 
